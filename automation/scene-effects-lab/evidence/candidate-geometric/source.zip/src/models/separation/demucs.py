"""Demucs stem separation: the vocal stem and the four instrument stems, cached per project."""
from pathlib import Path
import subprocess
import sys
import tempfile

STEMS = ('drums', 'bass', 'other')


def vocal_stem(audio, folder):
    """Cached Demucs vocal stem for the project, or None when separation is unavailable."""
    target = Path(folder)/'vocals.wav'
    if target.is_file() and target.stat().st_mtime >= Path(audio).stat().st_mtime:
        return target
    with tempfile.TemporaryDirectory(prefix='vocals-', dir=folder) as temp:
        result = subprocess.run([sys.executable, '-m', 'demucs', '--two-stems', 'vocals', '-n', 'htdemucs', '-o', temp, str(audio)],
                                capture_output=True, text=True, encoding='utf-8', errors='replace')
        stems = list(Path(temp).glob('htdemucs/*/vocals.wav'))
        if result.returncode or not stems:
            print(f'Warning: vocal separation unavailable; line starts keep the aligned timing. {result.stderr.strip()[-300:]}', flush=True)
            return None
        stems[0].replace(target)
    return target


def separate(audio, folder):
    """Four Demucs stems cached in the project's stems/ folder, or None when unavailable."""
    from core.files import file_digest, write_text_atomic
    target = Path(folder)/'stems'
    source = file_digest(audio)
    marker = target/'source.sha256'  # the digest of the song these stems were split from
    if all((target/f'{name}.wav').is_file() for name in STEMS):
        try:
            if marker.read_text(encoding='utf-8').strip() == source:
                return target
        except OSError:
            # Stems from before the marker existed: trust them while they are newer than the song.
            if all((target/f'{name}.wav').stat().st_mtime >= Path(audio).stat().st_mtime for name in STEMS):
                return target
    with tempfile.TemporaryDirectory(prefix='stems-', dir=folder) as temp:
        result = subprocess.run([sys.executable, '-m', 'demucs', '-n', 'htdemucs', '-o', temp, str(audio)],
                                capture_output=True, text=True, encoding='utf-8', errors='replace')
        found = list(Path(temp).glob('htdemucs/*'))
        if result.returncode or not found:
            print(f'Warning: instrument separation unavailable; no audio-reactive accents. {result.stderr.strip()[-300:]}', flush=True)
            return None
        target.mkdir(exist_ok=True)
        for stem in found[0].glob('*.wav'):
            stem.replace(target/stem.name)
        write_text_atomic(marker, source)
    return target
