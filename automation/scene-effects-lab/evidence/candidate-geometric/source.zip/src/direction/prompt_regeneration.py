"""Prepare every requested replacement prompt before loading an image pipeline."""
import copy
import json
from collections import defaultdict


def regenerate_prompts(worker,job,config,items,manifest=None):
    from direction.image_instruction_cleanup import clean_legacy_imported_meaning
    from direction.story import OPENING_FRAME,load,scene_brief
    story=load(manifest) if manifest else None
    segments={s.get('index'):s for s in (story or {}).get('segments',[])}  # a storyline keeps each new prompt on its moment
    job=dict(job,image_instructions=clean_legacy_imported_meaning(
        job.get('image_instructions',config.get('image_instructions',''))))
    from models.ollama.gpu import gpu_chat, release_model
    from models.ollama.catalog import resolve_prompt_model
    from models.ollama.service import local_json
    from direction.scenes import request_subjects
    from direction.verse import DIRECTOR_PROMPT, LANGUAGE_RULE, PEOPLE_RULE
    if job.get('artwork_mode')=='matte':
        from artwork.greenscreen import DIRECTOR_PROMPT
    from direction.illustration_prompts import image_prompt, uses_reference
    from models.image.catalog import model_spec
    batches=defaultdict(list)
    for item in items:
        model=item.get('model') or config.get('ai_model','auto')
        model=resolve_prompt_model(local_json,model)
        image_model=item.get('image_model') or config.get('image_model') or job['model']
        batches[(model,image_model,item.get('style') or '')].append(item)
    replacements={}
    for (model,image_model,style),batch in batches.items():
        worker.emit('subjects',0,message=f'Preparing {len(batch)} replacement prompt(s) with {model}')
        system=(DIRECTOR_PROMPT if job.get('artwork_mode') in ('verse','matte') else LANGUAGE_RULE+PEOPLE_RULE+
            'Interpret each lyric group into one fresh English visual scene for an illustrator. '
            'The lyrics determine subject matter, including Tagalog. Describe only visible forms, '
            'action, materials, lighting and mood in a detailed 120 to 180 word description. Choose subjects that best express the lyrics, '
            'including objects, places, weather, nature or small scenes, and people only when the lyric shows someone; vary compositions naturally. '
            'Follow the assigned composition and orientation. '
            'No text, captions, logos or copied lyric lines. Return only JSON with a subjects array in input order. ')
        told=any(i['index'] in segments for i in batch)
        system+=(' Show this moment of the story afresh rather than repeating the previous scene. '+OPENING_FRAME if told else
                 ' Invent a new interpretation rather than repeating the previous scene.')
        system+=' Apply optional user guidance and additional image instructions when they fit the lyrics.'
        if job.get('main_character'):
            from direction.reference_character import casting_rule
            system+=' '+casting_rule(job['main_character'])
        payload=dict(model=model,stream=False,think=False,keep_alive=-1,options=dict(num_ctx=8192),
            format=dict(type='object',properties=dict(subjects=dict(type='array',items=dict(type='string'))),required=['subjects']),
            messages=[dict(role='system',content=system),dict(role='user',content=json.dumps([
                dict(lyrics=job['groups'][i['index']],layout=job['layouts'][i['index']].get('prompt',''),
                     previous_scene=job.get('visual_descriptions',job['prompts'])[i['index']],guidance=i.get('prompt',''),
                     image_instructions=job.get('image_instructions',config.get('image_instructions','')),
                     **(scene_brief(segments[i['index']]) if i['index'] in segments else {})) for i in batch],ensure_ascii=False))])
        meanings=[]
        indices=[i['index'] for i in batch]
        # The same rule as prepare_job: references count only when this image model can take them.
        has_references=bool(job.get('reference_paths')) and model_spec(image_model)['references']
        groups=[job['groups'][i] for i in indices]
        try:
            from direction.song_gist import song_gist, attach_gist
            gist=job.get('song_gist') or song_gist(gpu_chat,model,[line for group in job['groups'] for line in group.split(' / ')],
                                                   job.get('image_instructions',config.get('image_instructions','')))
            if job.get('artwork_mode') in ('verse','matte'):
                from direction.verse import lyric_meanings
                guidance='\n'.join(str(item.get('prompt','')) for item in batch)
                meanings=lyric_meanings(gpu_chat,model,groups,
                                        image_instructions=(job.get('image_instructions',config.get('image_instructions',''))
                                                            +'\n'+guidance).strip(),song_gist=gist)
                inputs=json.loads(payload['messages'][1]['content'])
                for entry,meaning in zip(inputs,meanings):entry['lyric_meaning']=meaning
                payload['messages'][1]['content']=json.dumps(inputs,ensure_ascii=False)
            attach_gist(payload,gist)
            subjects=request_subjects(gpu_chat,payload,max_words=240 if job.get('artwork_mode')=='verse' else 180)
            technique=style or job.get('style_prompt',config.get('style_prompt',''))
            extra=job.get('image_instructions',config.get('image_instructions',''))
            if job.get('main_character'):
                extra=(casting_rule(job['main_character'])+extra).strip()
            prompts=[image_prompt(subject,job['layouts'][index],technique,has_references,job.get('reference_use')=='likeness')
                     + (' Additional image direction: '+extra if extra else '') for index,subject in zip(indices,subjects)]
            from direction.prompt_fit import fit_prompts
            prompts=fit_prompts(gpu_chat,model,image_model,prompts,technique)
        finally:release_model(model)
        for item,subject,prompt in zip(batch,subjects,prompts):
            index=item['index'];updated=copy.deepcopy(job)
            updated.setdefault('visual_descriptions',list(job['prompts']))[index]=subject
            updated['prompts'][index]=prompt
            if 'plate_prompts' in updated:
                from artwork.greenscreen import plate_prompt
                updated['plate_prompts'][index]=plate_prompt(subject,job['layouts'][index],style or job.get('style_prompt',config.get('style_prompt','')))
            if style:updated['style_prompt']=style
            if meanings:
                updated.setdefault('lyric_meanings',['']*len(job['groups']))[index]=meanings[indices.index(index)]
            updated['prompt_model']=model
            updated['song_gist']=gist
            if 'reference_modes' in updated:
                updated['reference_modes'][index]='image_conditioning' if has_references and uses_reference(job.get('artwork_mode'),subject) else 'technique_prompt_only'
            replacements[id(item)]=updated
        worker.emit('subjects',1,message=f'{len(batch)} replacement prompts ready; prompting model released')
    return [replacements[id(item)] for item in items]
